public class Edge implements Comparable<Edge>{
    private int u, v, cost;

    public Edge(int u, int v, int cost) {
        this.u = u;
        this.v = v;
        this.cost = cost;
    }

    public int getSource() {
        return this.u;
    }

    public int getDestination() {
        return this.v;
    }

    public int getCost() {
        return this.cost;
    }
    
    public String toString() {
        return "(" + this.getSource() + "," + this.getDestination() + ") = " + this.getCost();
    }    

    public int compareTo(Edge other) {

        if(this.cost > other.getCost()) {

            return 1;
        }
        else if(this.cost < other.getCost()) {

            return -1;
        }
        else {
            
            return 0;
        }
    }
}