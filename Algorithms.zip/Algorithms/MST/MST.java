import java.util.Collection;
import java.util.HashSet;
import java.util.Set;
import java.util.Queue;
import java.util.PriorityQueue;
import java.util.Vector;
import java.util.Stack;


public class MST {
   private Graph graph;
   private Vector<Edge> mst;

   public static final int INFINITE = Integer.MAX_VALUE;
    
   public MST(Graph graph) {
      this.graph = graph;
   }

   public void prim() {

    Vector<Edge> mstPrim = new Vector();
    Set<Integer> V = new HashSet<Integer>();
    Set<Integer> U = new HashSet<Integer>();

    // Initialize Sets
    for(int i=0; i<this.graph.getVertices(); i++) {

        V.add(i+1);
    }
    U.add(1);

    // Algorithms continues until U equals V
    while(!U.equals(V)) {

        // Get set U-V
        // Because mininmum cost edge has to have v IN U-V
        Set<Integer> temp = new HashSet<Integer>(V);
        for(Integer u : U) {
            if(V.contains(u)) {
                V.remove(u);
            }
        }
        Set<Integer> VminusU = new HashSet<Integer>(V);
        V = new HashSet<Integer>(temp);


        Integer uStart = U.iterator().next(); // first u in U
        Integer vStart = VminusU.iterator().next(); // first v in V
        Edge min = new Edge(uStart, vStart, this.graph.getCost(uStart, vStart)); // Set first edge to be min
        Integer vToAdd = vStart; // Edge(u,v) that is min, we need to add this v to U
        for(Integer i : U) { // For every in U
            for(Integer j : VminusU) {  // For eery in V-U

                Edge current = new Edge(i, j, this.graph.getCost(i, j)); // Current edge

                if(current.compareTo(min) < 0) { // If current edge cost is less than minimum

                    min = current; // min gets current
                    vToAdd = j; // v to add to U gets j
                }
            }
        }
        mstPrim.add(min); // Result vector adds min edge
        U.add(vToAdd); // U adds v 
    }// end while loop

    mst = mstPrim;
}

   public void kruskal() {

        Vector<Edge> mstKruskal = new Vector<Edge>();
        PriorityQueue<Edge> pq = new PriorityQueue<Edge>();

        for(int i=1; i <= this.graph.getVertices(); i++) {
            for(int j=1; j <= this.graph.getVertices(); j++) {

                Edge current = new Edge(i, j, this.graph.getCost(i, j));

                if(this.graph.getCost(i, j) != INFINITE) {

                    pq.add(current);
                }
            }
        }

        // Initialize
        Set<Integer> [] connectedComponents = new Set[this.graph.getVertices()+1];

        for(int i=1; i<connectedComponents.length; i++) {

            Set<Integer> current = new HashSet<Integer>();
            current.add((i));
            connectedComponents[i] = current;
        }

        while(pq.size() != 0) {

            Edge current = pq.peek();
            Integer u = current.getSource();
            Integer v = current.getDestination();

            int iInU = 0;
            int iInV = 0;
            for(int i=1; i<connectedComponents.length; i++) {

                if(connectedComponents[i].contains(u) &&
                    !connectedComponents[i].contains(v)) {

                        iInU = i;
                    }
                if(connectedComponents[i].contains(v)) {

                    iInV = i;
                }
            }

            // Component will be added
            if(iInU != 0 && iInV != 0) {

                //Move everything from v to u and delete v
                for(Integer i : connectedComponents[iInV]) {

                    connectedComponents[iInU].add(i);
                }
                connectedComponents[iInV].clear();
                mstKruskal.add(current);
                pq.remove(current);

                // Check if connectedComponents has all the vertices
                // If yes we can break from while loop
                if(connectedComponents[iInU].size() == this.graph.getVertices()) break;
            }
            else {

                pq.remove();
            }


        }

        mst = mstKruskal;
    }
    
   public Vector<Edge> getMST() {
       
      return this.mst;
   }
    
   public Graph getGraph() {

      return this.graph;
   }
}