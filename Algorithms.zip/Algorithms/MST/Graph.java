import java.lang.StringBuilder;

import javax.management.StringValueExp;

public class Graph {
    public static final int INFINITE = Integer.MAX_VALUE;
    private int vertices;
    private int[][] edges;

    public Graph(int vertices) {
        this.vertices = vertices;
        this.edges = new int[this.vertices][this.vertices];

        for (int i = 0; i < this.vertices; i++)
            for (int j = 0; j < this.vertices; j++)
                this.edges[i][j] = INFINITE;
    }

    public Graph(int [][] costs) {
        this.vertices = costs.length;
        this.edges = new int[this.vertices][this.vertices];

        for (int i = 0; i < this.vertices; i++)
            for (int j = 0; j < this.vertices; j++)
                this.edges[i][j] = (costs[i][j] == -1) ? INFINITE : costs[i][j];
    }

    public int getVertices() {
        return this.vertices;
    }

    public void setEgde(int u, int v, int cost) {
        if (u >= 1 && u <= this.vertices && v >= 1 && v <= this.vertices)
            this.edges[u - 1][v - 1] = cost;
    }

    public int getCost(int u, int v) {
        if (u >= 1 && u <= this.vertices && v >= 1 && v <= this.vertices)
            return this.edges[u - 1][v - 1];
        else         
            return INFINITE;
    }

    public String toString(String s) {

        StringBuilder stringValue = new StringBuilder();
        stringValue.append(s + "\n\n");

        for(int i=0; i < this.vertices; i++) {
            stringValue.append("[" + String.valueOf(i+1) + "]" + "  ");
            for(int j=0; j< this.vertices; j++) {
                if(this.edges[i][j] == INFINITE) {
                    stringValue.append("----   ");
                }
                else {
                    stringValue.append(String.valueOf(this.edges[i][j]) + "    ");
                }

            }
            stringValue.append("\n");
        }
        return (stringValue.toString());
    }
}