import java.util.Vector;

public class MSTTest {

    /*
     * The minimum-cost spanning tree connects all the vertices of a graph at minimum cost 
     *  
     */
     
    public static void printMST(String title, MST mst, boolean graph) {    
       int cost = 0;
 
       if (graph)
          System.out.println(mst.getGraph().toString("Graph"));
         
       System.out.println(title + "\n");
         
       Vector<Edge> tree = mst.getMST();
         
       for (Edge e : tree) {
          cost = cost + e.getCost();
             
          System.out.println(e.toString());
       }
         
       System.out.println("\nMST cost is " + cost + "\n");
    }
 
    public static void main(String[] args) {
         
       int [][] cost = { { -1,  6,  1,  5, -1, -1 },
                         {  6, -1,  5, -1,  3, -1 },
                         {  1,  5, -1,  5,  6,  4 },
                         {  5, -1,  5, -1, -1,  2 },
                         { -1,  3,  6, -1, -1,  6 },
                         { -1, -1,  4,  2,  6, -1 } };

                         int [][] cost1 = { { -1, 2, -1, 6, -1 },
                         { 2, -1, 3, 8, 5 },
                         { -1, 3, -1, -1, 7 },
                         { 6, 8, -1, -1, 9 },
                         { -1, 5, 7, 9, -1 } };
                           
      MST mst = new MST(new Graph(cost));
         
      mst.prim();
      printMST("Prim's Minimum-cost Spanning Tree (MST)", mst, true);
      mst.kruskal(); 
      printMST("Kruskal's Minimum-cost Spanning Tree (MST)", mst, false);

      MST mst1 = new MST(new Graph(cost1));

      mst1.prim();
      printMST("Prim's Minimum-cost Spanning Tree (MST)", mst1, true);
      mst1.kruskal(); 
      printMST("Kruskal's Minimum-cost Spanning Tree (MST)", mst1, false);
 
    }
 }