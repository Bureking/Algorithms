public class Knapsack {
    int weight;
    int value;
    double [] percentage;
    
    public Knapsack(int items) {
        this.weight = 0;
        this.value = 0;
        this.percentage = new double[items];
    }
}
