public class Item {
    String id;
    public int value;
    public int weight;
    public double ratio;

    public Item(String id, int value, int weight) {
        this.id = id;
        this.value = value;
        this.weight = weight;
        this.ratio = (double)value / (double)weight;
    }
}
    
