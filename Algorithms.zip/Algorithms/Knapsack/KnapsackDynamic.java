public class KnapsackDynamic {

	int weight;
	Item [] items;
	int [][] T;
	boolean [][] S;
    Knapsack knapsack;
	
	public KnapsackDynamic(int weight, Item[] items) {
		
        // initialize the KnapsackDynamic
		this.weight=weight;
		this.items=items.clone();
		this.T=new int[this.items.length][this.weight+1];
		this.S=new boolean[this.items.length][this.weight+1];
        this.knapsack = new Knapsack(items.length);

        
		// 2 for loops to build the tablers
        for(int i=0; i<this.items.length; i++) {
            for(int j=0; j<=this.weight; j++) {

                // Case 1: 0 if 𝑤0 > 𝑊, the weight of item 0 is greater that the knapsack weight
				if(j == 0) {
					this.T[i][0] = 0;
                    this.S[i][0] = false;
				}
                // Case 2: 𝑣0 if 𝑤0 ≤𝑊, the weight of item 0is less or equal to the knapsack weight
                else if(i==0) {
                    this.T[0][j] = this.items[0].value;
                    this.S[0][j] = true;
                }

                // Case 3: 𝑇[𝑖−1, 𝑗]if 𝑤𝑖 is greater than the knapsack weight
                else if(this.items[i].weight > j) {
                    this.T[i][j] = this.T[i-1][j];
                    this.S[i][j] = false;
                }

                // Case 4: max(𝑇[𝑖−1][j], 𝑇[𝑖−1][𝑗−𝑤𝑖] +𝑣𝑖 when none of the above cases are true
                else {
                    this.T[i][j] = max(T[i-1][j], T[i-1][j-this.items[i].weight] + this.items[i].value);
                    this.S[i][j] = this.T[i][j] == this.T[i-1][j] ? false : true;

                }
			}
        }
    }

        

	public static int max(int a, int b) {
        return (a > b) ? a : b;
    }
						
	
	public Knapsack getKnapsack(int weight) {


        int i = this.items.length-1;
        int j = this.weight;

        // While weight is > 0
        while(j > 0) {

            // If we do not use the item at S[i][j] move up
            if(S[i][j] == false) {
                i--;
            }  
            // We are using the item, add it to the knapsack
            else {
                j -= this.items[i].weight;
                this.knapsack.weight += this.items[i].weight;
                this.knapsack.value += this.items[i].value;
                this.knapsack.percentage[i] = 1;
            }      
        
        }
        
        return this.knapsack;


	}	
}