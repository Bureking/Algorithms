import java.util.Collection;
import java.util.HashSet;
import java.util.Set;
import java.util.Queue;
import java.util.PriorityQueue;
import java.util.Vector;
import java.util.Stack;


public class TravellingSalesman {

   private Graph graph;
   private Vector<Edge> mst;
   public static final int INFINITE = Integer.MAX_VALUE;
   private String[] cities;
    
   public TravellingSalesman(Graph graph, String[] cities) {

      this.graph = graph;
      this.cities = cities;
   }

   public Vector<Edge> solveNB(String startingCity) {

        Vector<Edge> NBsolution = new Vector<Edge>();


        // Get the starting position
        int startCity = getCity(startingCity);

        while(NBsolution.size() != this.graph.getVertices() - 1) {

            // Find the minimum from startCity
            Edge min = new Edge(startCity, startCity, this.graph.getCost(startCity, startCity));
            for(int i=1; i < this.graph.getVertices() + 1; i++) {

                Edge current = new Edge(startCity, i, this.graph.getCost(startCity, i));

                if(current.compareTo(min) < 0 && !contain(current, NBsolution) ) {
                    min = current;
                }
            }
            //Add min to the solution
            NBsolution.add(min);

            String nextCity = getCity(min.getDestination());
            startCity = getCity(nextCity);
        }
        Edge lastCity = NBsolution.lastElement();

        Edge lastConnection = new Edge(lastCity.getDestination(), getCity(startingCity), this.graph.getCost(lastCity.getDestination(), getCity(startingCity)));

        NBsolution.add(lastConnection);

        this.mst = NBsolution;

        return mst;
}

    public Vector<Edge> solveMST(String startingCity) {

        Vector<Edge> mstSolution = new Vector<Edge>();

         // Get the starting position
         int startCity = getCity(startingCity);

         //Initialize sets
         // Initialize Sets
         Set<Integer> V = new HashSet<Integer>();
         Set<Integer> U = new HashSet<Integer>();
         for(int i=0; i<this.graph.getVertices(); i++) {

             V.add(i+1);
         }
         U.add(startCity);

    
         Integer uStart = U.iterator().next(); // first u in U
         // Algorithms continues until U equals V
        while(!U.equals(V)) {

        // Get set U-V
        // Because mininmum cost edge has to have v IN U-V
        Set<Integer> temp = new HashSet<Integer>(V);
        for(Integer u : U) {
            if(V.contains(u)) {
                V.remove(u);
            }
        }
        Set<Integer> VminusU = new HashSet<Integer>(V);
        V = new HashSet<Integer>(temp); 

        Integer vStart = VminusU.iterator().next(); // first v in V
        Edge min = new Edge(uStart, vStart, this.graph.getCost(uStart, vStart)); // Set first edge to be min
        Integer vToAdd = vStart; // Edge(u,v) that is min, we need to add this v to U
        for(int i=uStart; i <= uStart; i++) { 
            for(Integer j : VminusU) {  // For every in V-U

                Edge current = new Edge(i, j, this.graph.getCost(i, j)); // Current edge

                if(current.compareTo(min) < 0) { // If current edge cost is less than minimum 

                    min = current; // min gets current
                    vToAdd = j; // v to add to U gets j
                }
            }
        }
        uStart = min.getDestination();
        mstSolution.add(min); // Result vector adds min edge
        U.add(vToAdd); // U adds v 
    }

    Edge lastCity = mstSolution.lastElement();

    Edge lastConnection = new Edge(lastCity.getDestination(), getCity(startingCity), this.graph.getCost(lastCity.getDestination(), getCity(startingCity)));
    mstSolution.add(lastConnection);
    
    this.mst = mstSolution;

    return mst;
}

    public boolean contain(Edge edge, Vector<Edge> vec) {

        if(edge.getSource() == edge.getDestination()) return true;
        
        for(Edge e : vec) {
            if(edge.getDestination() == e.getSource()) return true;
        }
        return false;
      
    }

   public Vector<Edge> getMST() {

        return this.mst;
   }

   public Graph getGraph() {

      return this.graph;
   }

   public String getCity(int i) {

    return this.cities[i];
   }

    
    public int getCity(String city) {
        int value = 0;
        for(int i=0; i < this.cities.length; i++) {
            if(cities[i] == city) {
                value = i;
            } 
        }
        return value;
    }
}
