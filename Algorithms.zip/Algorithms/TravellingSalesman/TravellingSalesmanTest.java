import java.util.Vector;

public class TravellingSalesmanTest {



   public static void printNB(String startingCity, TravellingSalesman ts) {    

      int cost = 0;
  
      System.out.println("TSP Nearest Neighbor heuristic starting from " + startingCity  + "\n");
        
      Vector<Edge> tree = ts.solveNB(startingCity);
        
      for (Edge e : tree) {
         cost = cost + e.getCost();

         System.out.print(ts.getCity(e.getSource()) + " -> " + ts.getCity(e.getDestination()) + "    " + e.getCost());
         System.out.println();
            
      }
        
      System.out.println("\nTotal cost is " + cost + "\n");
   }

   public static void printMST(String startingCity, TravellingSalesman ts) {    

      int cost = 0;
  
      System.out.println("TSP Prim's heuristic starting from " + startingCity  + "\n");
        
      Vector<Edge> tree = ts.solveMST(startingCity);
        
      for (Edge e : tree) {
         cost = cost + e.getCost();

         System.out.print(ts.getCity(e.getSource()) + " -> " + ts.getCity(e.getDestination()) + "    " + e.getCost());
         System.out.println();
            
      }
        
      System.out.println("\nTotal cost is " + cost + "\n");
   }
  
 
    public static void main(String[] args) {
         
      int [][] km = { {-1,  1118,    644,    535,    683,    995,    334,    609,   1153,   1010,    340,    738,    473,    763,    947,    676,    961,    455,    411,    833},
                { 1118,    -1,    620,    583,    918,    908,    784,    621,    997,    590,    902,    437,    778,    529,   1046,    453,    349,    663,    759,    296},
                {  644,   620,     -1,    158,    605,    795,    359,    395,    939,    796,    304,    159,    395,    119,    993,    257,    633,    280,    376,    324},
                {  535,   583,    158,     -1,    447,    637,    201,    237,    781,    638,    322,    203,    237,    232,    775,    141,    517,    122,    218,    287},
                {  683,   918,    605,    447,    -1,     319,    407,    297,    506,    654,    525,    650,    210,    679,    264,    490,    636,    325,    272,    622},
                {  995,   908,    795,    637,    319,     -1,    733,    400,    187,    444,    851,    807,    529,    869,    138,    631,    545,    578,    616,    725},
                {  334,   784,    359,    201,    407,    733,     -1,    333,    877,    734,    118,    404,    197,    433,    671,    342,    685,    134,    135,    488},
                {  609,   621,    395,    237,    297,    400,    333,     -1,    544,    401,    451,    407,    212,    469,    538,    231,    352,    193,    248,    325},
                { 1153,   997,    939,    781,    506,    187,    877,    544,     -1,    407,    995,    951,    756,   1013,    219,    775,    648,    737,    792,    869},
                { 1010,   590,    796,    638,    654,    444,    734,    401,    407,     -1,    852,    714,    613,    807,    534,    589,    241,    594,    649,    539},
                {  340,   902,    304,    322,    525,    851,    118,    451,    995,    852,     -1,    463,    315,    423,    789,    463,    803,    252,    253,    604},
                {  738,   437,    159,    203,    650,    807,    404,    407,    951,    714,    463,     -1,    440,     92,    945,    176,    501,    325,    421,    175},
                {  473,   778,    395,    237,    210,    529,    197,    212,    756,    613,    315,    440,     -1,    469,    474,    325,    564,    115,     62,    482},
                {  763,   529,    119,    232,    679,    869,    433,    469,   1013,    807,    423,     92,    469,     -1,   1007,    268,    594,    354,    450,    268},
                {  947,  1046,    993,    775,    264,    138,    671,    538,    219,    534,    789,    945,    474,   1007,     -1,    769,    697,    589,    536,    863},
                {  676,   453,    257,    141,    490,    631,    342,    231,    775,    589,    463,    176,    325,    268,    769,     -1,    376,    210,    306,    157},
                {  961,   349,    633,    517,    636,    545,    685,    352,    648,    241,    803,    501,    564,    594,    697,    376,     -1,    545,    600,    326},
                {  455,   663,    280,    122,    325,    578,    134,    193,    737,    594,    252,    325,    115,    354,    589,    210,    545,     -1,     96,    367},
                {  411,   759,    376,    218,    272,    616,    135,    248,    792,    649,    253,    421,     62,    450,    536,    306,    600,     96,     -1,    463},
                {  833,   296,    324,    287,    622,    725,    488,    325,    869,    539,    604,    175,    482,    268,    863,    157,    326,    367,    463,    -1} };

      Graph graph = new Graph(km);

      String[] cities = createCities();
      
      TravellingSalesman ts = new TravellingSalesman(graph, cities);



      for(int i=1; i < graph.getVertices() + 1 ; i++) { // i < graph.getVertices() + 1 to get output for all cities
         printNB(ts.getCity(i), ts);
         printMST(ts.getCity(i), ts);
      }

    }

    public static String[] createCities() {

      String[] cities = new String[21];
  
      for(int i=1; i<cities.length; i++) {
          switch (i) {
              case 1:
                  cities[1] = "A Coruna";
                  break;
              case 2:
                  cities[2] = "Barcelona";
                  break;
              case 3:
                  cities[3] = "Bilbao";
                  break;
              case 4:
                  cities[4] = "Burgos";
                  break;
              case 5:
                  cities[5] = "Caceres";
                  break;
              case 6: 
                  cities[6] = "Cordoba";
                  break;
              case 7:
                  cities[7] = "Leon";
                  break;
              case 8:
                  cities[8] = "Madrid";
                  break;
              case 9:
                  cities[9] = "Malaga";
                  break;
              case 10:
                  cities[10] = "Murcia";
                  break;
              case 11:
                  cities[11] = "Oviedo";
                  break;
              case 12:
                  cities[12] = "Pamplona";
                  break;
              case 13:
                  cities[13] = "Salamanca";
                  break;
              case 14:
                  cities[14] = "San Sebastian";
                  break;
              case 15:
                  cities[15] = "Sevilla";
                  break;
              case 16:
                  cities[16] = "Soria";
                  break;
              case 17:
                  cities[17] = "Valencia";
                  break;
              case 18:
                  cities[18] = "Valladolid";
                  break;
              case 19:
                  cities[19] = "Zamora";
                  break;
              case 20:
                  cities[20] = "Zaragoza";
                  break;
              }
          }
          return cities;
      } 
}
 