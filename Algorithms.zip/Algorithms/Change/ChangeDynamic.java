public class ChangeDynamic {
    int change;
    int [] money;
    int [][] T;
    boolean [][] S;
    
    public ChangeDynamic(int [] money, int change) {

       this.change = change;
       this.money = money.clone();
       this.T = new int[this.money.length][this.change+1];
       this.S = new boolean[this.money.length][this.change+1];

       for(int i=0; i < this.money.length; i++){
           for(int j=0; j <= this.change; j++) {
               if(j == 0) {
                   this.T[i][j] = 0;
               }
               else if(i == 0) {
                   this.T[i][j] = j;
                   this.S[i][j] = true;
               }
               else if(this.money[i] > j){
                   this.T[i][j] = this.T[i-1][j];
                   this.S[i][j] = false;
               }
               else {
                   this.T[i][j] = min(this.T[i-1][j], 1+this.T[i][j-this.money[i]]);
                   this.S[i][j] = this.T[i][j] == this.T[i-1][j] ? false : true;
               }
           }
       }
    }
    
    public int [] getChange(int change) {
        int[] coins = new int[this.money.length];
        int i = this.T.length-1;
        int j = this.T[0].length-1;
        while(j > 0) {
            if(j > 0) {
                if(S[i][j] == false) {
                    i--;
                }
                else {
                    coins[i]++;
                    j -= this.money[i];
                }
            }
        }
        return coins;
    }

    private static int min(int a, int b) {
       return (a > b) ? b : a;
    }
}