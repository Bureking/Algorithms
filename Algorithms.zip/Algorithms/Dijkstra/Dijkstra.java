import java.util.HashSet;
import java.util.Set;
import java.util.Stack;

public class Dijkstra {
    private Graph graph;
    private int [] D;
    private int [] P;

    public static final int INFINITE = Integer.MAX_VALUE;
    
    public Dijkstra(Graph graph) {
        this.graph = graph;
        this.D = new int[this.graph.getVertices() + 1];
        this.P = new int[this.graph.getVertices() + 1];
    }

    public Graph getGraph() {
        return this.graph;        
    }    

    public ShortestPath solve() {
        // Dijkstra's algorithm uses three sets: V (vertices of the graph), S (vertices to explore), and V-S    
        // V = {1, 2, ... , n }, V contains all the vertices of the graph
        // S = {1}, initially contains vertex 1
        // D[k] is the minimum cost path from vertex 1 to vertex k
        // P[k] is the previous vertex of the shortest path from vertex 1 to vertex k
        // running Dijkstra with the graph below, D is [--, 10, 50, 30, 60], and P is [--, 1, 4, 1, 3] 
        // the return value is an object ShortestPath containing the array D and an array of String with the shortest path

        Set<Integer> S = new HashSet<Integer>();
        Set<Integer> V = new HashSet<Integer>();

        String[] path = new String[this.graph.getVertices()+1];
    
        // Initialize V and S
        for(int i=1; i < this.graph.getVertices() + 1; i++) {

            V.add(i);
        }
        S.add(1);

        // Initailize D
        for(int i=2; i < this.D.length; i++) {
            D[i] = this.graph.getCost(1, i);
        }
        
        while(!S.equals(V)) {

            // Get set V-S
            Set<Integer> temp = new HashSet<Integer>(V);
            for(Integer s : S) {
                if(V.contains(s)) {
                    V.remove(s);
                }
            }
            Set<Integer> VminusS = new HashSet<Integer>(V);
            V = new HashSet<Integer>(temp);

            // Find min index and mincost
            int indexOfMinCost = VminusS.iterator().next();
            int minCost = D[indexOfMinCost];
            for(Integer w : VminusS) {

                if(D[w] < minCost) {
                    minCost = D[w];
                    indexOfMinCost = w;
                }
            }
            // add min to S
            S.add(indexOfMinCost);

            // If it is a direct path
            if(D[indexOfMinCost] == graph.getCost(1, indexOfMinCost)) {
                P[indexOfMinCost] = 1;
            }

            // Update D and P
            for(Integer i : VminusS) {
                if(i == indexOfMinCost) {
                    continue;
                }
                else {
                    int a = D[indexOfMinCost];
                    int b = graph.getCost(indexOfMinCost, i);

                    // Important condition, because getCost function can return MAX_INTEGER
                    // If we add something to MAX_INTEGER it will go into negatives
                    // And then min() would return unexpected value
                    if(b != INFINITE) {
                        D[i] = Math.min(D[i], a+b);
                        P[i] = D[i] == (a+b) ? indexOfMinCost : i;
                    }
                }
            }                
        } 
    
    // Go through P and build the paths
    for(int i=2; i < P.length; i++) {

        // If last vertex is 1 = direct path
        if(P[i] == 1) {
            path[i] = "1-" + String.valueOf(i);

        }

        else {

            path[i] =  "-"+ String.valueOf(i);

            int lastVisited = P[i];

            while(lastVisited != 1) {

                //To visit vertex i last vertex we visited was P[i]
                // so add P[i] to path
                path[i] = "-" + String.valueOf(lastVisited) + path[i];

                lastVisited = P[lastVisited];
            }
            path[i] = String.valueOf(1) + path[i];

        }
    } 

        ShortestPath sp = new ShortestPath(D, path);

        return sp;
    }



    public static int min(int a, int b) {
    
            return (a < b) ? a : b;
    }
}