public class ShortestPath {
    private int [] cost;
    private String [] path;

    public ShortestPath(int [] cost, String [] path) {
        this.cost = cost.clone();
        this.path = path.clone();
    }
    
    public int [] getCost() {
        return this.cost;
    }
    
    public String [] getPath() {
        return this.path;
    }
}