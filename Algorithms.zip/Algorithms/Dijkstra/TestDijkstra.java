public class TestDijkstra {

    public static void main(String[] args) {
        int [][] cost = { { -1, 10, -1, 30, 100},
                          { -1, -1, 50, -1,  -1},
                          { -1, -1, -1, -1,  10},
                          { -1, -1, 20, -1,  60},
                          { -1, -1, -1, -1,  -1} };
        
        Dijkstra dijkstra = new Dijkstra(new Graph(cost));
        
        
        ShortestPath d = dijkstra.solve();
        
        
        int [] mincost = d.getCost();
        String [] path = d.getPath();
        
        System.out.println(dijkstra.getGraph().toString("Graph"));        
        System.out.println("Dijkstra's Shortest Path from vertex 1 \n");
        
        for (int i=2; i<path.length; i++) {
            System.out.println(path[i] + " with cost " + mincost[i]);
        }
        
        
        int [][] cost1 = {{ -1, 10, 40, 100, 20},
                          { -1, -1, 10, -1,  5},
                          { -1, -1, -1, 40,  -1},
                          { -1, -1, -1, -1,  15},
                          { -1, -1, -1, -1,  -1}};
        System.out.println();

        Dijkstra dijkstra1 = new Dijkstra(new Graph(cost1));

        d = dijkstra1.solve();
        mincost = d.getCost();
        path = d.getPath();

        System.out.println(dijkstra1.getGraph().toString("Graph1"));        
        System.out.println("Dijkstra's Shortest Path from vertex 1 \n");

        for (int i=2; i<path.length; i++) {
            System.out.println(path[i] + " with cost " + mincost[i]);
        }
        

    }
}
